<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])) {
	echo "<center>Untuk mengakses modul, ANda harus login <br>";
	echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else {
	include "../../../lib/config.php";
	include "../../../lib/koneksi.php";
	
	$nama_file = $_FILES['gambar']['name'];
	$ukuran_file = $_FILES['gambar']['size'];
	$tipe_file = $_FILES['gambar']['type'];
	$tmp_file = $_FILES ['gambar']['tmp_name'];
	$nama_file = $_FILES['gambar']['name'];

	$idKategori = $_POST['idKategori'];
	$idMerek = $_POST['idMerek'];
	$idProduk = $_POST ['id_produk'];
	$namaProduk = $_POST ['nama_produk'];
	$hargaProduk = $_POST ['harga'];
	$slide = $_POST['slide'];
	$rekomendasi = $_POST['rekomendasi'];
	
	$path= "../../upload/" . $nama_file;
	if ($tipe_file == "image/jpeg" || $tipe_file== "image/png") {
	
		if ($ukuran_file <= 1000000){
		
			if(move_uploaded_file($tmp_file, $path)) {
			
			$queryEdit = mysql_query("UPDATE tbl_produk SET id_kategori_produk='$idKategori',id_merek='$idMerek',nama_produk='$namaProduk',gambar='$nama_file',harga='.$hargaProduk.' WHERE id_produk='$idProduk'");
			if ($queryEdit){
				echo "<script> alert('Data Produk berhasil diubah'); window.location = '$admin_url' +'adminweb.php?module=produk';</script>";
			} else {
				echo "<script> alert('Data Produk GAGAL diubah'); window.location = '$admin_url' +'adminweb.php?module=produk';</script>";
			}
		} else {
			echo "<script> alert('Data Gambar Produk GAGAL diubah karena melebihi 1 mb'); window.location = '$admin_url' +'adminweb.php?module=produk';</script>";
		}
	}else {
		echo "<script> alert('Data Gambar Produk GAGAL diubah karena tidak berextensi jpeg/png'); window.location = '$admin_url' +'adminweb.php?module=produk';</script>";
		}
	}

	}
	?>
	